#ifndef CREATOBJECT_H
#define CREATOBJECT_H


class creatobject
{
public:
    creatobject();
};

#endif // CREATOBJECT_H
