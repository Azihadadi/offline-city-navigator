#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "map.h"
#include "MapGraph.h"
#include "utility.h"
#include <fstream>
//open CV menus creatation
#include <opencv2/highgui.hpp>
#include <QPushButton>
#include <QVBoxLayout>
#include <QFileDialog>
using namespace std;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->informationGroupBox->setVisible(false);
    ui->warningLabel->setVisible(false);
    ui->errorLabel->setVisible(false);
    ui->groupBox->setVisible(false);
    ui->servicesCheckBox->setChecked(false);
    waitKey();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_findPathBotton_clicked()
{
    ui->informationGroupBox->setVisible(false);
    ui->warningLabel->setVisible(false);
    vector<int> bakaryList = {7,12,48,47,16};
    vector<string> bakaryTextList = {"Boulanger Patissier Banette","Durque Eric","Passion Chocolat C Duchet","Chateau de la Verrerie","Fleurentin David"};
    vector<int> restaurantList = {46,49,5,43,14};
    vector<string> restaurantTextList = {"La Smeralda","Royal Tacos","McDonald","Le Sabb Thai Association","Le Roi De la Pizza"};
    vector<int> hotelList = {22,44};
    vector<string> hotelTextList = {"Hotel La Petite Verrerie","Le Creusot Hotel"};
    vector<int> caffeeList = {11,35};
    vector<string> caffeeTextList = {"Pause Caffee","El Loco Caffee"};
    int depature;
    string message;
    QStringList myOptions;
    myOptions <<"Centre Universitaire Condorcet"<< "Carrefour Market"<< "Residence Jean Moulin"<<"Residence Les Acacias"<<"IUT Le Creusot"<<"Post Office"<<"Gare SNCF Le Creusot"<<"Larc-Scene Nationale Europeenne"
             <<"Boulanger Patissier Banette"<<"Durque Eric"<<"Passion Chocolat C Duchet"<<"Chateau de la Verrerie"<<"Fleurentin David"
            <<"La Smeralda"<<"Royal Tacos"<<"McDonald's"<<"Le Sabb Thai Association"<<"Le Roi De la Pizza"
           <<"Hotel La Petite Verrerie"<<"Le Creusot Hotel"
          <<"Pause Caffee"<<"El Loco Caffee"
         <<"Proxy epicerie le creusot du roi";

    QString source_txt= ui->sourceValue->currentText();
    switch (myOptions.indexOf(source_txt)) {
    case 0:
        depature = 0;
        break;
    case 1:
        depature = 9;
        break;
    case 2:
        depature = 21;
        break;
    case 3:
        depature = 36;
        break;
    case 4:
        depature = 51;
        break;
    case 5:
        depature = 10;
        break;
    case 6:
        depature = 6;
        break;
    case 7:
        depature = 61;
        break;
    case 8:
        depature = 12;
        break;
    case 9:
        depature = 48;
        break;
    case 10:
        depature = 47;
        break;
    case 11:
        depature = 16;
        break;
    case 12:
        depature = 39;
        break;
    case 13:
        depature = 46;
        break;
    case 14:
        depature = 49;
        break;
    case 15:
        depature = 5;
        break;
    case 16:
        depature = 43;
        break;
    case 17:
        depature = 14;
        break;
    case 18:
        depature = 22;
        break;
    case 19:
        depature = 44;
        break;
    case 20:
        depature = 11;
        break;
    case 21:
        depature = 35;
        break;
    case 22:
        depature = 18;
        break;
    default:
        depature =19;
        break;
    }
    QString destiantion_txt=ui->destinationValue->currentText();
    int destination;
    switch (myOptions.indexOf(destiantion_txt)) {
    case 0:
        destination = 0;
        break;
    case 1:
        destination = 9;
        break;
    case 2:
        destination = 21;
        break;
    case 3:
        destination = 36;
        break;
    case 4:
        destination = 51;
        break;
    case 5:
        destination = 10;
        break;
    case 6:
        destination = 6;
        break;
    case 7:
        destination = 61;
        break;
    case 8:
        destination = 12;
        break;
    case 9:
        destination = 48;
        break;
    case 10:
        destination = 47;
        break;
    case 11:
        destination = 16;
        break;
    case 12:
        destination = 39;
        break;
    case 13:
        destination = 46;
        break;
    case 14:
        destination = 49;
        break;
    case 15:
        destination = 5;
        break;
    case 16:
        destination = 43;
        break;
    case 17:
        destination = 14;
        break;
    case 18:
        destination = 22;
        break;
    case 19:
        destination = 44;
        break;
    case 20:
        destination = 11;
        break;
    case 21:
        destination = 35;
        break;
    case 22:
        destination = 18;
        break;
    default:
        destination =19;
        break;
    }
    QString via_txt=ui->viaValue->currentText();
    int via;
    switch (myOptions.indexOf(via_txt)) {
    case 0:
        via = 0;
        break;
    case 1:
        via = 9;
        break;
    case 2:
        via = 21;
        break;
    case 3:
        via = 36;
        break;
    case 4:
        via = 51;
        break;
    case 5:
        via = 10;
        break;
    case 6:
        via = 6;
        break;
    case 7:
        via = 61;
        break;
    case 8:
        via = 12;
        break;
    case 9:
        via = 48;
        break;
    case 10:
        via = 47;
        break;
    case 11:
        via = 16;
        break;
    case 12:
        via = 39;
        break;
    case 13:
        via = 46;
        break;
    case 14:
        via = 49;
        break;
    case 15:
        via = 5;
        break;
    case 16:
        via = 43;
        break;
    case 17:
        via = 14;
        break;
    case 18:
        via = 22;
        break;
    case 19:
        via = 44;
        break;
    case 20:
        via = 11;
        break;
    case 21:
        via = 35;
        break;
    case 22:
        via = 18;
        break;
    default:
        via =19;
        break;
    }

    int startLocation=depature;
    int viaLocation=via;
    int endLocation=destination;
    int rout1[MAX_POINTS];
    int rout2[MAX_POINTS];
    int totalPoints=0;
    int totalPointsStartToIntermidiate=0;
    int totalPointsIntermidiateToEnd=0;
    string line;
    Map city;
    int x=0, y=0;
    char ch;
    unsigned index=1;
    if(via_txt.compare(EMPTY_OPTION) == 0)
    {
        // calculate the path
        totalPoints=pathPlanning(Graph,MAX_POINTS,startLocation,endLocation,rout1);
        ifstream path_file (MAP_COORDINATION);
        if (path_file.is_open())
        {
            while (!path_file.eof())
            {
                path_file >>x>>ch>>y;
                city.path.push_back(Point(x,y));
                index=index+1;
            }
            path_file.close();
        }
        else cout << "Unable to open file";
        Point P;
        for(int i=0;i<totalPoints;i++)
        {
            if(ui->servicesCheckBox->isChecked()){
                //search bakaries
                if(ui->bakaryRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(bakaryList.begin(), bakaryList.end(), unsigned(rout1[i]));
                    if (it != bakaryList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
                //search restaurants
                else if(ui->restauranReadioButton->isChecked()){
                    vector<int>::iterator it = std::find(restaurantList.begin(), restaurantList.end(), unsigned(rout1[i]));
                    if (it != restaurantList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
                //search hotels
                else if(ui->hotelRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(hotelList.begin(), hotelList.end(), unsigned(rout1[i]));
                    if (it != hotelList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
                //search caffees
                else if(ui->caffeeRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(caffeeList.begin(), caffeeList.end(), unsigned(rout1[i]));
                    if (it != caffeeList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
            }else
                city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
        }
        if(source_txt.compare(EMPTY_OPTION) != 0 && destiantion_txt.compare(EMPTY_OPTION) != 0 && !ui->servicesCheckBox->isChecked()){
            city.shortestpath.push_back(city.path.at(unsigned(startLocation)));
            city.shortestpath.push_back(city.path.at(unsigned(endLocation)));
            ui->informationGroupBox->setVisible(true);
            ui->walkingTimeValue->setText(QString::fromStdString("Time: "+to_string(totalPoints*1)+" min"));
            ui->drivingTimeValue->setText(QString::fromStdString("Time: "+to_string((totalPoints*15)/60)+" min"));
        }else{
            ui->informationGroupBox->setVisible(false);
        }
    }
    else
    {
        // calculate the shortest path is going through intermediate point
        totalPointsStartToIntermidiate=pathPlanning(Graph,MAX_POINTS,startLocation,viaLocation,rout1);
        totalPointsIntermidiateToEnd=pathPlanning(Graph,MAX_POINTS,viaLocation,endLocation,rout2);
        ifstream path_file (MAP_COORDINATION);
        if (path_file.is_open())
        {
            while (!path_file.eof())
            {
                path_file >>x>>ch>>y;
                city.path.push_back(Point(x,y));
                index=index+1;
            }
            path_file.close();
        }
        else cout << "Unable to open file";
        Point P1;

        for(int i=0;i<totalPointsStartToIntermidiate;i++)
        {
            if(ui->servicesCheckBox->isChecked()){

                //search bakaries
                if(ui->bakaryRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(bakaryList.begin(), bakaryList.end(), unsigned(rout1[i]));
                    if (it != bakaryList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
                //search restaurants
                else if(ui->restauranReadioButton->isChecked()){
                    vector<int>::iterator it = std::find(restaurantList.begin(), restaurantList.end(), unsigned(rout1[i]));
                    if (it != restaurantList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
                //search hotels
                else if(ui->hotelRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(hotelList.begin(), hotelList.end(), unsigned(rout1[i]));
                    if (it != hotelList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
                //search caffees
                else if(ui->caffeeRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(caffeeList.begin(), caffeeList.end(), unsigned(rout1[i]));
                    if (it != caffeeList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
            }else
                city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
        }
        for(int i=0;i<totalPointsIntermidiateToEnd;i++)
        {
            if(ui->servicesCheckBox->isChecked()){
                //search bakaries
                if(ui->bakaryRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(bakaryList.begin(), bakaryList.end(), unsigned(rout2[i]));
                    if (it != bakaryList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout2[i])));
                }
                //search restaurants
                else if(ui->restauranReadioButton->isChecked()){
                    vector<int>::iterator it = std::find(restaurantList.begin(), restaurantList.end(), unsigned(rout2[i]));
                    if (it != restaurantList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout2[i])));
                }
                //search hotels
                else if(ui->hotelRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(hotelList.begin(), hotelList.end(), unsigned(rout2[i]));
                    if (it != hotelList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
                //search caffees
                else if(ui->caffeeRadioButton->isChecked()){
                    vector<int>::iterator it = std::find(caffeeList.begin(), caffeeList.end(), unsigned(rout2[i]));
                    if (it != caffeeList.end())
                        city.shortestpath.push_back(city.path.at(unsigned(rout1[i])));
                }
            }
            else
                city.shortestpath.push_back(city.path.at(unsigned(rout2[i])));

        }
        if(source_txt.compare(EMPTY_OPTION) != 0 && destiantion_txt.compare(EMPTY_OPTION) != 0 && !ui->servicesCheckBox->isChecked()){
            city.shortestpath.push_back(city.path.at(unsigned(startLocation)));
            city.shortestpath.push_back(city.path.at(unsigned(endLocation)));
            ui->informationGroupBox->setVisible(true);
            ui->walkingTimeValue->setText(QString::fromStdString(to_string(totalPointsStartToIntermidiate+totalPointsIntermidiateToEnd)+" min"));
            ui->drivingTimeValue->setText(QString::fromStdString(to_string(((totalPointsStartToIntermidiate+totalPointsIntermidiateToEnd)*15)/60)+" min"));
        }else
        {
            ui->informationGroupBox->setVisible(false);
        }
    }
    if(city.shortestpath.size() != 0 && source_txt.compare(EMPTY_OPTION) != 0 && destiantion_txt.compare(EMPTY_OPTION) != 0){
        city.org= loadFromQrc(MAP_IMAGE);
        putTextOnimage(city.org,city.path.at(unsigned(startLocation)),source_txt.toStdString());
        putTextOnimage(city.org,city.path.at(unsigned(endLocation)),destiantion_txt.toStdString());
        if(via_txt.compare(EMPTY_OPTION) != 0)
        {
            putTextOnimage(city.org,city.path.at(unsigned(viaLocation)),via_txt.toStdString());
        }
        markerSelector(&city, "shape");
        city.marker = loadFromQrc(PATH_MARKER);
        displayShortestPath(&city);
    }else if(city.shortestpath.size() == 0  && source_txt.compare(EMPTY_OPTION) != 0 && destiantion_txt.compare(EMPTY_OPTION) != 0 && ui->servicesCheckBox->isChecked())
    {
        string message;
        if(city.shortestpath.size() == 0){
            ui->warningLabel->setVisible(true);
            if(ui->bakaryRadioButton->isChecked()){
                message = "There is no bakary in the shortest path between "+source_txt.toStdString()+" and "+destiantion_txt.toStdString();
                if(via_txt.compare(EMPTY_OPTION) != 0)
                {
                    message += " via " + via_txt.toStdString();
                }
                ui->warningLabel->setText(QString::fromStdString(message));
            }else if (ui->restauranReadioButton->isChecked()){
                message = "There is no restaurant in the shortest path between "+source_txt.toStdString()+" and "+destiantion_txt.toStdString();
                if(via_txt.compare(EMPTY_OPTION) != 0)
                {
                    message += " via " + via_txt.toStdString();
                }
                ui->warningLabel->setText(QString::fromStdString(message));
            }else if(ui->hotelRadioButton->isChecked()){
                message = "There is no hotel in the shortest path between "+source_txt.toStdString()+" and "+destiantion_txt.toStdString();
                if(via_txt.compare(EMPTY_OPTION) != 0)
                {
                    message += " via " + via_txt.toStdString();
                }
                ui->warningLabel->setText(QString::fromStdString(message));
            }else if(ui->caffeeRadioButton->isChecked()){
                message = "There is no caffee in the shortest path between "+source_txt.toStdString()+" and "+destiantion_txt.toStdString();
                if(via_txt.compare(EMPTY_OPTION) != 0)
                {
                    message += " via " + via_txt.toStdString();
                }
                ui->warningLabel->setText(QString::fromStdString(message));
            }
        }
    }
    else if(source_txt.compare(EMPTY_OPTION) == 0 || destiantion_txt.compare(EMPTY_OPTION) == 0){
        cout<<"3333333333333"<<endl;
        ui->warningLabel->setVisible(true);
        ui->warningLabel->setText(QString::fromStdString("Error: Please select the departure and destination."));
    }
}

void MainWindow::on_findLocationBotton_clicked()
{
    int position=0;
    int x=0,y=0;
    int index=0;
    char ch;
    ui->errorLabel->setVisible(false);
    cv::Mat path_map, path_update;
    Map Le_Creusot;
    vector<string> locationList = {"Château de la Verrerie","Larc - Scene nationale Europeenne","Eglise Saint-Lauren","Pavillon de l'industrie","Post Office","Hotel La Petite Verrerie","Le Creusot Hôtel"};
    vector<int>locationIndexList = {17,61,19,16,10,22,44};
    ifstream path_file (MAP_COORDINATION);
    if (path_file.is_open())
    {
        while (!path_file.eof())
        {
            path_file >>x>>ch>>y;
            Le_Creusot.path.push_back(Point(x,y));
            index=index+1;
        }
        path_file.close();
    }
    else cout << "Unable to open file";
    Le_Creusot.org = loadFromQrc(MAP_IMAGE);
    Le_Creusot.marker = loadFromQrc(PATH_MARKER);
    QString location_text = ui->comboBox->currentText();
    if(location_text.toStdString().compare(EMPTY_OPTION) != 0){
        for(int i=0; i<locationList.size(); i++)
        {
            if(location_text.toStdString().compare(locationList.at(unsigned(i)))==0)
            {
                position=locationIndexList.at(unsigned(i));
                break;
            }
        }
        overlayImage(Le_Creusot.org,Le_Creusot.marker,path_map,Le_Creusot.path.at(unsigned(position)));
        putTextOnimage(path_map,Le_Creusot.path.at(unsigned(position)),location_text.toStdString());
        Le_Creusot.org = loadFromQrc(MAP_IMAGE);
        Le_Creusot.marker = loadFromQrc(PATH_MARKER);
        Map::centerizedWindow("location display",path_map);
        imshow("location display", path_map);
        waitKey();
    }else
    {
        ui->errorLabel->setVisible(true);
        ui->errorLabel->setText(QString::fromStdString("Error: Please select a location."));
    }
}

void MainWindow::on_selectMapBotton_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    tr("Open Address Book"), "",
                                                    tr("Address Book (*.abk);;All Files (*)"));
    cv::Mat img;
    img = cv::imread(fileName.toStdString(),1);
    Map::centerizedWindow("Le Creusot Map",img);
    imshow("Le Creusot Map", img);
    waitKey();
}

void MainWindow::on_displayMapBotton_clicked()
{
    Map Le_creusot;
    cv::Mat img;
    calculateShortestPath(ROOT_FILE, &Le_creusot);
    Le_creusot.org=  loadFromQrc(MAP_IMAGE);
    Le_creusot.marker = loadFromQrc(FIND_MARKER,5);
    Map::centerizedWindow("Add Location",Le_creusot.org);
    cv::setMouseCallback("Add Location", &Map::on_mouse, &Le_creusot );
    imshow("Add Location", Le_creusot.org);
    waitKey();
}

void MainWindow::on_hotelButton_clicked()
{
    showServices(hotelList,hotelTextList);
}

void MainWindow::on_restaurantButton_clicked()
{
    showServices(restaurantList,restaurantTextList);
}

void MainWindow::on_caffeeButton_clicked()
{
    showServices(caffeeList,caffeeTextList);
}

void MainWindow::on_bakaryButton_clicked()
{
    showServices(bakaryList,bakaryTextList);
}

void MainWindow::on_servicesCheckBox_stateChanged(int arg1)
{
    if(ui->servicesCheckBox->isChecked())
    {
        ui->groupBox->setVisible(true);
    }else
    {
        ui->bakaryRadioButton->setChecked(false);
        ui->restauranReadioButton->setChecked(false);
        ui->hotelRadioButton->setChecked(false);
        ui->caffeeRadioButton->setChecked(false);
        ui->groupBox->setVisible(false);
    }
}

