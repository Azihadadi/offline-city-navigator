#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv;
cv::Mat org;
int n=0;
vector<Point> capturePoint;// point coordinates, global variable;
void on_mouse(int ,int ,int ,int ,void *ustc);
void on_mouse(int event,int x,int y,int flags,void *ustc)
{
    Point pt;//mouse position;
    char coordinate[16];

    if (event == EVENT_LBUTTONDOWN)
    {
        pt = Point(x,y);
        cout<<x<<" "<<y<<endl;
        capturePoint.push_back(pt);
        n++;

        circle(org,pt,2,Scalar(255,0,0,0),FILLED,8,0);
        sprintf(coordinate,"(%d,%d)",x,y);
        putText(org,coordinate,pt,FONT_HERSHEY_SIMPLEX,0.5,Scalar(0,0,0,255),1,8);

        //imshow("org",org);

        if(n>=4)//only four points are needed;
        {
            imshow("org",org);
            cv::destroyAllWindows();
        }
    }
}
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // read an image
    org = imread("1.jpg",1);

    namedWindow("org",1);
    setMouseCallback("org",on_mouse,0);//mouse callback function;

    imshow("org",org);
    //cout<<n<<endl;

    cout<<capturePoint.size()<<endl;
    ofstream file("sample.txt");//save coordinates to txt file;
    if(!file)
    {
        cout << "open file error!";
    }
    vector<Point>::iterator it=capturePoint.begin();
    for(;it!=capturePoint.end();++it)
    {
        file<< it->x<<','<<it->y<<endl;
    }
    //file<<endl;
    file.close();

    waitKey(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}












int main()
{

}
