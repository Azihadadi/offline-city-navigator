#include "creatobject.h"

creatobject::creatobject()
{

}
