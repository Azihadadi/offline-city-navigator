#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "map.h"
using namespace std;
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_findPathBotton_clicked();
    void on_findLocationBotton_clicked();
    void on_selectMapBotton_clicked();
    void on_displayMapBotton_clicked();
    void on_hotelButton_clicked();
    void on_restaurantButton_clicked();
    void on_caffeeButton_clicked();
    void on_bakaryButton_clicked();
    void on_servicesCheckBox_stateChanged(int arg1);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
