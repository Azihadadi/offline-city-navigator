#include <utility.h>
#include <QApplication>
#include <QDesktopWidget>

Utility::Utility(){}

vector<string> Utility::split (const string &s, char delim) {
    vector<string> result;
    stringstream ss (s);
    string item;
    while (getline (ss, item, delim)) {
        result.push_back (item);
    }
    return result;
}
