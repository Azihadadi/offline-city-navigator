#include "map.h"
#include "mainwindow.h"
#include <iostream>
#include <fstream>
#include <QApplication>
#include <QDesktopWidget>

Map::Map(){}

void Map::on_mouse(int event,int x,int y,int flags,void *ustc)
{
    Map *pThis = static_cast<Map*>(ustc);
    Mat out_map;
    if(event == EVENT_LBUTTONDOWN) {
        ofstream file(EXAMPLE_FILE,std::ios_base::app);//save coordinates to txt file;
        if(!file)
        {
            cout << "open file error!";
            cout<<flags<<endl;
            cout<<&pThis<<endl;
        }
        else
        {
            file<<x<<','<<y<<endl;
            cout << "(" << x << ", " << y << ")" << endl;
            file.close();
            markerSelector(pThis, "shape");
            namedWindow("Le Creusot Map");
            if(pThis->select_marker_type == "circle_marker")
            {
                circle(pThis->org,Point(x,y),10,Scalar(255,255,0),FILLED,LINE_8,0);
                Map::centerizedWindow("Le Creusot Map",pThis->org);
                imshow("Le Creusot Map", pThis->org);
            }
            else if(pThis->select_marker_type =="from_file_maker")
            {
                overlayImage(pThis->org,pThis->marker,out_map,Point(x,y));
                Map::centerizedWindow("Le Creusot Map",out_map);
                imshow("Le Creusot Map", out_map);
            }
            waitKey();
        }
    }
}
void overlayImage(const cv::Mat &background, const cv::Mat &foreground, cv::Mat &output, cv::Point2i location)
{
    background.copyTo(output);
    // start at the row indicated by location, or at row 0 if location.y is negative.
    for(int y = std::max(location.y , 0); y < background.rows; ++y)
    {
        int fY = y - location.y; // because of the translation
        // we are done of we have processed all rows of the foreground image.
        if(fY >= foreground.rows)
            break;
        // start at the column indicated by location,
        // or at column 0 if location.x is negative.
        for(int x = std::max(location.x, 0); x < background.cols; ++x)
        {
            int fX = x - location.x; // because of the translation.
            // we are done with this row if the column is outside of the foreground image.
            if(fX >= foreground.cols)
                break;
            // determine the opacity of the foregrond pixel, using its fourth (alpha) channel.
            double opacity =
                    ((double)foreground.data[fY * foreground.step + fX * foreground.channels() + 3])
                    / 255.;
            // and now combine the background and foreground pixel, using the opacity,
            // but only if opacity > 0.
            for(int c = 0; opacity > 0 && c < output.channels(); ++c)
            {
                unsigned char foregroundPx =
                        foreground.data[fY * foreground.step + fX * foreground.channels() + c];
                unsigned char backgroundPx =
                        background.data[y * background.step + x * background.channels() + c];
                output.data[y*output.step + output.channels()*x + c] =
                        backgroundPx * (1.-opacity) + foregroundPx * opacity;
            }
        }
    }
}
void calculateShortestPath(string filename, Map *city)
{
    string line;
    int x, y;
    char ch;
    unsigned index=1;
    cout<<filename<<endl;
    ifstream path_file (filename);
    if (path_file.is_open())
    {
        while (!path_file.eof())
        {
            path_file >>x>>ch>>y;
            cout<<x<<","<<y<<endl;
            city->path.push_back(Point(x,y));
            index=index+1;
        }
        path_file.close();
    }
    else cout << "Unable to open file";
}
void displayShortestPath(Map *city)
{
    unsigned size_of_path;
    cv::Mat path_map, path_update;
    unsigned i;
    size_of_path= city->shortestpath.size();
    path_update =city->org;
    for(i=0;i<size_of_path;i++)
    {
        cout<<city->shortestpath[i]<<endl;
        overlayImage(path_update,city->marker,path_map,city->shortestpath[i]);
        path_update = path_map;
    }
    Map::centerizedWindow("Le Creusot Map",path_map);
    imshow("Le Creusot Map", path_map);
    waitKey();
}
void markerSelector(Map *city, string choice)
{
    if(choice == "shape")
    {
        city->select_marker_type = "circle_marker";
    } else
    {
        city->select_marker_type = "from_file_maker";
    }
}
void shortestpath(int state, void* userdata)
{
    Map *pThis = static_cast<Map*>(userdata);
    cout<<"print out button value"<<state<<endl;
    cout<<pThis->path<<endl;
}
int pathPlanning(int G[MAX_POINTS][MAX_POINTS],int n,int startnode, int endpoint, int R[MAX_POINTS]) {
    int cost[MAX_POINTS][MAX_POINTS],distance[MAX_POINTS],pred[MAX_POINTS];
    int visited[MAX_POINTS],count,mindistance,nextnode,i,j;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            if(G[i][j]==0)
                cost[i][j]=INFINITY_SIZE;
            else
                cost[i][j]=G[i][j];
    for(i=0;i<n;i++) {
        distance[i]=cost[startnode][i];
        pred[i]=startnode;
        visited[i]=0;
    }
    distance[startnode]=0;
    visited[startnode]=1;
    count=1;
    while(count<n-1) {
        mindistance=INFINITY_SIZE;
        for(i=0;i<n;i++)
            if(distance[i]<mindistance&&!visited[i]) {
                mindistance=distance[i];
                nextnode=i;
            }
        visited[nextnode]=1;
        for(i=0;i<n;i++)
            if(!visited[i])
                if(mindistance+cost[nextnode][i]<distance[i]) {
                    distance[i]=mindistance+cost[nextnode][i];
                    pred[i]=nextnode;
                }
        count++;
    }
    int k=0;
    for(i=0;i<n;i++)
        if(i!=startnode & endpoint == i) {
            j=i;
            do {
                j=pred[j];
                R[k]=j;
                k=k+1;
            }while(j!=startnode);
        }
    return k;
}
int **MakeAdjacencyMap(int height, int width, string filename)
{
    int** graph2D = nullptr;
    graph2D = new int*[unsigned(height)];

    string line;
    int x;
    unsigned index=1;
    cout<<endl;
    ifstream path_file;
    path_file.open(filename);
    if (path_file.is_open())
    {
        while (!path_file.eof())
        {
            path_file >>line;
            if (stringstream(line) >> x)
                for (int h = 0; h < height; h++)
                {
                    graph2D[h] = new int[unsigned(width)];

                    for (int w = 0; w < width; w++)
                    {
                        graph2D[h][w] = std::stoi(line);
                        cout <<graph2D[h][w] <<endl;
                    }
                }
            index=index+1;
        }
        path_file.close();
    }
    else
    {
        cout << "Unable to open file"<<endl;
    }
    return graph2D;
}
void putTextOnimage(cv::Mat Image,cv::Point coordinate,string text)
{
    cv::putText(Image,
                text,
                coordinate,
                cv::FONT_HERSHEY_SIMPLEX,
                0.5,
                cv::Scalar(85,85,127),
                2);
}
map<char,int> Map::getCenterOfScreen()
{
    map<char,int> center;
    QDesktopWidget *desktop = QApplication::desktop();
    center['x']=desktop->screenGeometry().center().x();
    center['y']= desktop->screenGeometry().center().y();
    return center;
}
void Map::centerizedWindow(string name, Mat mat)
{
    namedWindow(name,cv::WINDOW_AUTOSIZE);
    moveWindow(name, getCenterOfScreen().at('x')-((mat.size().width)/2),getCenterOfScreen().at('y')-((mat.size().height)/2));
}

Mat loadFromQrc(string qrc, int flag)
{
    QFile file(QString::fromStdString((qrc)));
    Mat m;
    if(file.open(QIODevice::ReadOnly))
    {
        qint64 sz = file.size();
        std::vector<uchar> buf(sz);
        file.read((char*)buf.data(), sz);
        m = imdecode(buf, flag);
    }
    return m;
}
void showServices(vector<int> servicePositionList,vector<string> serviceTextList)
{
    int x=0,y=0;
    int index=0;
    char ch;
    cv::Mat path_map, path_update;
    Map Le_Creusot;
    ifstream path_file (MAP_COORDINATION);
    if (path_file.is_open())
    {
        while (!path_file.eof())
        {
            path_file >>x>>ch>>y;
            Le_Creusot.path.push_back(Point(x,y));
            index=index+1;
        }
        path_file.close();
    }
    else cout << "Unable to open file";
    Le_Creusot.org = loadFromQrc(MAP_IMAGE);
    Le_Creusot.marker = loadFromQrc(PATH_MARKER);
    path_update =Le_Creusot.org;
    for(int i=0; i<servicePositionList.size(); i++)
    {
        overlayImage(path_update,Le_Creusot.marker,path_map,Le_Creusot.path.at(unsigned(servicePositionList[i])));
        path_update = path_map;
        putTextOnimage(path_update,Le_Creusot.path.at(unsigned(servicePositionList[i])),serviceTextList[i]);
        path_update = path_map;
    }
    Le_Creusot.org = loadFromQrc(MAP_IMAGE);
    Le_Creusot.marker = loadFromQrc(PATH_MARKER);
    Map::centerizedWindow("location display",path_map);
    imshow("location display", path_map);
    waitKey();
}

