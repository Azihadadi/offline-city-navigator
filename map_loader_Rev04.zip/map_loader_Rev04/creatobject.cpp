#include "creatobject.h"

creatobject::creatobject()
{

}
Mat img;
bool applyGray=false;
bool applyBlur=false;
bool applySobel=false;
…
int main( int argc, const char** argv )
{
  // Read images
  img= imread("...
