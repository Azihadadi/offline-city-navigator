#include <QApplication>
#include<QSlider>
#include<QSpinBox>
#include<QHBoxLayout>
#include<QWidget>
#include "mainwindow.h"
#include<QMenuBar>
#include<QStatusBar>
using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
