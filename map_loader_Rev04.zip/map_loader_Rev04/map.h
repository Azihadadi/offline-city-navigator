#ifndef MAP_H
#define MAP_H
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>
#include <vector>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <cstdio>
#include <QFile>
using namespace std;
using namespace cv;

static string ProjectDirectory ="D://Software_engineering_project//map_loader//files//";
const string GRAPH_FILE =ProjectDirectory + "location_graph.txt";
const string MAP_COORDINATION = ProjectDirectory + "default_root.txt";
const string ROOT_FILE = ProjectDirectory + "root.txt";
const string EXAMPLE_FILE = ProjectDirectory + "example.txt";
const string MAP_IMAGE = "://images//maps//Le_Creusot_Map.jpg";
const string FIND_MARKER ="://images//icons//find_marker.png";
const string PATH_MARKER ="://images//icons//pathMarker.jpg";
const vector<int> bakaryList = {7,12,48,47,16};
const vector<string> bakaryTextList = {"Boulanger Patissier Banette","Durque Eric","Passion Chocolat C Duchet","Chateau de la Verrerie","Fleurentin David"};
const vector<int> restaurantList = {46,49,5,43,14};
const vector<string> restaurantTextList = {"La Smeralda","Royal Tacos","McDonald","Le Sabb Thai Association","Le Roi De la Pizza"};
const vector<int> hotelList = {22,44};
const vector<string> hotelTextList = {"Hotel La Petite Verrerie","Le Creusot Hotel"};
const vector<int> caffeeList = {11,35};
const vector<string> caffeeTextList = {"Pause Caffee","El Loco Cafffee"};
#define INFINITY_SIZE 9999
#define MAX_POINTS 62
#define EMPTY_OPTION "-- Select Item --"

class Map
{
private:
    string m_winname;
public:
    static Point pt;//mouse position;
    Mat org;
    Mat marker;
    vector<Point> path;
    vector<Point> shortestpath;
    string select_marker_type;
    char coordinate[16];
    Map();
    static void on_mouse(int,int,int,int,void *);
    static map<char,int> getCenterOfScreen();
    static void centerizedWindow(string,cv::Mat mat);
};
void overlayImage(const cv::Mat&, const cv::Mat&, cv::Mat&, cv::Point2i);
void calculateShortestPath(string, Map*);
void displayShortestPath(Map*);
void markerSelector(Map*, string);
void shortestpath(int, void*);
int pathPlanning(int G[MAX_POINTS][MAX_POINTS],int ,int, int, int R[MAX_POINTS]);
int **MakeAdjacencyMap(int, int, string);
void putTextOnimage(cv::Mat,cv::Point ,string);
Mat loadFromQrc(string qrc, int flag = IMREAD_COLOR);
void showServices(vector<int>,vector<string>);
#endif
// MAP_H
