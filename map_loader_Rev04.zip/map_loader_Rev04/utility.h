#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>
#include <vector>
using namespace std;
using namespace cv;
#ifndef UTILITY_H
#define UTILITY_H
class Utility
{    
    public:
    Utility();
    static vector<string> split (const string &s, char delim);
};
#endif // UTILITY_H
